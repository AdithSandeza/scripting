
// var client;
// let vm;
// let _this = this;
// let params;


// document.onreadystatechange = function() {
//   if (document.readyState === 'interactive') renderApp();

//   function renderApp() {
//     var onInit = app.initialized();

//     onInit.then(getClient).catch(handleErr);

//     function getClient(_client) {
//     client = _client;
//       client.events.on('app.activated', onAppActivate);


      
//       // Vue.filter('formatDateDiffForHumans', function(value) {
//       //   if (!value) return null;
//       //   return dayjs(value).format('h:mm A');
//       // });

//       vm = new Vue({
//         el: '#app',
//         data: {
//          searchInfo:'',
//          posts : [{"first":"John","last":"Doe","suffix":"#1"},{"first":"John","last":"Doe","suffix":"#2"},{"first":"John","last":"Doe","suffix":"#3"},{"first":"John","last":"Doe","suffix":"#4"},{"first":"John","last":"Doe","suffix":"#5"},{"first":"John","last":"Doe","suffix":"#6"},{"first":"John","last":"Doe","suffix":"#7"},{"first":"John","last":"Doe","suffix":"#8"},{"first":"John","last":"Doe","suffix":"#9"},{"first":"John","last":"Doe","suffix":"#10"},{"first":"John","last":"Doe","suffix":"#11"},{"first":"John","last":"Doe","suffix":"#12"},{"first":"John","last":"Doe","suffix":"#13"},{"first":"John","last":"Doe","suffix":"#14"},{"first":"John","last":"Doe","suffix":"#15"},{"first":"John","last":"Doe","suffix":"#16"},{"first":"John","last":"Doe","suffix":"#17"},{"first":"John","last":"Doe","suffix":"#18"},{"first":"John","last":"Doe","suffix":"#19"},{"first":"John","last":"Doe","suffix":"#20"},{"first":"John","last":"Doe","suffix":"#21"},{"first":"John","last":"Doe","suffix":"#22"},{"first":"John","last":"Doe","suffix":"#23"},{"first":"John","last":"Doe","suffix":"#24"},{"first":"John","last":"Doe","suffix":"#25"},{"first":"John","last":"Doe","suffix":"#26"},{"first":"John","last":"Doe","suffix":"#27"},{"first":"John","last":"Doe","suffix":"#28"},{"first":"John","last":"Doe","suffix":"#29"},{"first":"John","last":"Doe","suffix":"#30"},{"first":"John","last":"Doe","suffix":"#31"},{"first":"John","last":"Doe","suffix":"#32"},{"first":"John","last":"Doe","suffix":"#33"},{"first":"John","last":"Doe","suffix":"#34"},{"first":"John","last":"Doe","suffix":"#35"},{"first":"John","last":"Doe","suffix":"#36"},{"first":"John","last":"Doe","suffix":"#37"},{"first":"John","last":"Doe","suffix":"#38"},{"first":"John","last":"Doe","suffix":"#39"},{"first":"John","last":"Doe","suffix":"#40"},{"first":"John","last":"Doe","suffix":"#41"},{"first":"John","last":"Doe","suffix":"#42"},{"first":"John","last":"Doe","suffix":"#43"},{"first":"John","last":"Doe","suffix":"#44"},{"first":"John","last":"Doe","suffix":"#45"},{"first":"John","last":"Doe","suffix":"#46"},{"first":"John","last":"Doe","suffix":"#47"},{"first":"John","last":"Doe","suffix":"#48"},{"first":"John","last":"Doe","suffix":"#49"},{"first":"John","last":"Doe","suffix":"#50"},{"first":"John","last":"Doe","suffix":"#51"},{"first":"John","last":"Doe","suffix":"#52"},{"first":"John","last":"Doe","suffix":"#53"},{"first":"John","last":"Doe","suffix":"#54"},{"first":"John","last":"Doe","suffix":"#55"},{"first":"John","last":"Doe","suffix":"#56"},{"first":"John","last":"Doe","suffix":"#57"},{"first":"John","last":"Doe","suffix":"#58"},{"first":"John","last":"Doe","suffix":"#59"},{"first":"John","last":"Doe","suffix":"#60"},{"first":"John","last":"Doe","suffix":"#61"},{"first":"John","last":"Doe","suffix":"#62"},{"first":"John","last":"Doe","suffix":"#63"},{"first":"John","last":"Doe","suffix":"#64"},{"first":"John","last":"Doe","suffix":"#65"},{"first":"John","last":"Doe","suffix":"#66"},{"first":"John","last":"Doe","suffix":"#67"},{"first":"John","last":"Doe","suffix":"#68"},{"first":"John","last":"Doe","suffix":"#69"},{"first":"John","last":"Doe","suffix":"#70"},{"first":"John","last":"Doe","suffix":"#71"},{"first":"John","last":"Doe","suffix":"#72"},{"first":"John","last":"Doe","suffix":"#73"},{"first":"John","last":"Doe","suffix":"#74"},{"first":"John","last":"Doe","suffix":"#75"},{"first":"John","last":"Doe","suffix":"#76"},{"first":"John","last":"Doe","suffix":"#77"},{"first":"John","last":"Doe","suffix":"#78"},{"first":"John","last":"Doe","suffix":"#79"},{"first":"John","last":"Doe","suffix":"#80"},{"first":"John","last":"Doe","suffix":"#81"},{"first":"John","last":"Doe","suffix":"#82"},{"first":"John","last":"Doe","suffix":"#83"},{"first":"John","last":"Doe","suffix":"#84"},{"first":"John","last":"Doe","suffix":"#85"},{"first":"John","last":"Doe","suffix":"#86"},{"first":"John","last":"Doe","suffix":"#87"},{"first":"John","last":"Doe","suffix":"#88"},{"first":"John","last":"Doe","suffix":"#89"},{"first":"John","last":"Doe","suffix":"#90"},{"first":"John","last":"Doe","suffix":"#91"},{"first":"John","last":"Doe","suffix":"#92"},{"first":"John","last":"Doe","suffix":"#93"},{"first":"John","last":"Doe","suffix":"#94"},{"first":"John","last":"Doe","suffix":"#95"},{"first":"John","last":"Doe","suffix":"#96"},{"first":"John","last":"Doe","suffix":"#97"},{"first":"John","last":"Doe","suffix":"#98"},{"first":"John","last":"Doe","suffix":"#99"},{"first":"John","last":"Doe","suffix":"#100"},{"first":"John","last":"Doe","suffix":"#101"},{"first":"John","last":"Doe","suffix":"#102"},{"first":"John","last":"Doe","suffix":"#103"},{"first":"John","last":"Doe","suffix":"#104"},{"first":"John","last":"Doe","suffix":"#105"},{"first":"John","last":"Doe","suffix":"#106"},{"first":"John","last":"Doe","suffix":"#107"},{"first":"John","last":"Doe","suffix":"#108"},{"first":"John","last":"Doe","suffix":"#109"},{"first":"John","last":"Doe","suffix":"#110"},{"first":"John","last":"Doe","suffix":"#111"},{"first":"John","last":"Doe","suffix":"#112"},{"first":"John","last":"Doe","suffix":"#113"},{"first":"John","last":"Doe","suffix":"#114"},{"first":"John","last":"Doe","suffix":"#115"},{"first":"John","last":"Doe","suffix":"#116"},{"first":"John","last":"Doe","suffix":"#117"},{"first":"John","last":"Doe","suffix":"#118"},{"first":"John","last":"Doe","suffix":"#119"},{"first":"John","last":"Doe","suffix":"#120"},{"first":"John","last":"Doe","suffix":"#121"},{"first":"John","last":"Doe","suffix":"#122"},{"first":"John","last":"Doe","suffix":"#123"},{"first":"John","last":"Doe","suffix":"#124"},{"first":"John","last":"Doe","suffix":"#125"},{"first":"John","last":"Doe","suffix":"#126"},{"first":"John","last":"Doe","suffix":"#127"},{"first":"John","last":"Doe","suffix":"#128"},{"first":"John","last":"Doe","suffix":"#129"},{"first":"John","last":"Doe","suffix":"#130"},{"first":"John","last":"Doe","suffix":"#131"},{"first":"John","last":"Doe","suffix":"#132"},{"first":"John","last":"Doe","suffix":"#133"},{"first":"John","last":"Doe","suffix":"#134"},{"first":"John","last":"Doe","suffix":"#135"},{"first":"John","last":"Doe","suffix":"#136"},{"first":"John","last":"Doe","suffix":"#137"},{"first":"John","last":"Doe","suffix":"#138"},{"first":"John","last":"Doe","suffix":"#139"},{"first":"John","last":"Doe","suffix":"#140"},{"first":"John","last":"Doe","suffix":"#141"},{"first":"John","last":"Doe","suffix":"#142"},{"first":"John","last":"Doe","suffix":"#143"},{"first":"John","last":"Doe","suffix":"#144"},{"first":"John","last":"Doe","suffix":"#145"},{"first":"John","last":"Doe","suffix":"#146"},{"first":"John","last":"Doe","suffix":"#147"},{"first":"John","last":"Doe","suffix":"#148"},{"first":"John","last":"Doe","suffix":"#149"},{"first":"John","last":"Doe","suffix":"#150"},{"first":"John","last":"Doe","suffix":"#151"},{"first":"John","last":"Doe","suffix":"#152"},{"first":"John","last":"Doe","suffix":"#153"},{"first":"John","last":"Doe","suffix":"#154"},{"first":"John","last":"Doe","suffix":"#155"},{"first":"John","last":"Doe","suffix":"#156"},{"first":"John","last":"Doe","suffix":"#157"},{"first":"John","last":"Doe","suffix":"#158"},{"first":"John","last":"Doe","suffix":"#159"},{"first":"John","last":"Doe","suffix":"#160"},{"first":"John","last":"Doe","suffix":"#161"},{"first":"John","last":"Doe","suffix":"#162"},{"first":"John","last":"Doe","suffix":"#163"},{"first":"John","last":"Doe","suffix":"#164"},{"first":"John","last":"Doe","suffix":"#165"},{"first":"John","last":"Doe","suffix":"#166"},{"first":"John","last":"Doe","suffix":"#167"},{"first":"John","last":"Doe","suffix":"#168"},{"first":"John","last":"Doe","suffix":"#169"},{"first":"John","last":"Doe","suffix":"#170"},{"first":"John","last":"Doe","suffix":"#171"},{"first":"John","last":"Doe","suffix":"#172"},{"first":"John","last":"Doe","suffix":"#173"},{"first":"John","last":"Doe","suffix":"#174"},{"first":"John","last":"Doe","suffix":"#175"},{"first":"John","last":"Doe","suffix":"#176"},{"first":"John","last":"Doe","suffix":"#177"},{"first":"John","last":"Doe","suffix":"#178"},{"first":"John","last":"Doe","suffix":"#179"},{"first":"John","last":"Doe","suffix":"#180"},{"first":"John","last":"Doe","suffix":"#181"},{"first":"John","last":"Doe","suffix":"#182"},{"first":"John","last":"Doe","suffix":"#183"},{"first":"John","last":"Doe","suffix":"#184"},{"first":"John","last":"Doe","suffix":"#185"},{"first":"John","last":"Doe","suffix":"#186"},{"first":"John","last":"Doe","suffix":"#187"},{"first":"John","last":"Doe","suffix":"#188"},{"first":"John","last":"Doe","suffix":"#189"},{"first":"John","last":"Doe","suffix":"#190"},{"first":"John","last":"Doe","suffix":"#191"},{"first":"John","last":"Doe","suffix":"#192"},{"first":"John","last":"Doe","suffix":"#193"},{"first":"John","last":"Doe","suffix":"#194"},{"first":"John","last":"Doe","suffix":"#195"},{"first":"John","last":"Doe","suffix":"#196"},{"first":"John","last":"Doe","suffix":"#197"},{"first":"John","last":"Doe","suffix":"#198"},{"first":"John","last":"Doe","suffix":"#199"}],
//          pages : [{"first":"John","last":"Doe","suffix":"#1"},{"first":"John","last":"Doe","suffix":"#2"},{"first":"John","last":"Doe","suffix":"#3"},{"first":"John","last":"Doe","suffix":"#4"},{"first":"John","last":"Doe","suffix":"#5"},{"first":"John","last":"Doe","suffix":"#6"},{"first":"John","last":"Doe","suffix":"#7"},{"first":"John","last":"Doe","suffix":"#8"},{"first":"John","last":"Doe","suffix":"#9"},{"first":"John","last":"Doe","suffix":"#10"},{"first":"John","last":"Doe","suffix":"#11"},{"first":"John","last":"Doe","suffix":"#12"},{"first":"John","last":"Doe","suffix":"#13"},{"first":"John","last":"Doe","suffix":"#14"},{"first":"John","last":"Doe","suffix":"#15"},{"first":"John","last":"Doe","suffix":"#16"},{"first":"John","last":"Doe","suffix":"#17"},{"first":"John","last":"Doe","suffix":"#18"},{"first":"John","last":"Doe","suffix":"#19"},{"first":"John","last":"Doe","suffix":"#20"},{"first":"John","last":"Doe","suffix":"#21"},{"first":"John","last":"Doe","suffix":"#22"},{"first":"John","last":"Doe","suffix":"#23"},{"first":"John","last":"Doe","suffix":"#24"},{"first":"John","last":"Doe","suffix":"#25"},{"first":"John","last":"Doe","suffix":"#26"},{"first":"John","last":"Doe","suffix":"#27"},{"first":"John","last":"Doe","suffix":"#28"},{"first":"John","last":"Doe","suffix":"#29"},{"first":"John","last":"Doe","suffix":"#30"},{"first":"John","last":"Doe","suffix":"#31"},{"first":"John","last":"Doe","suffix":"#32"},{"first":"John","last":"Doe","suffix":"#33"},{"first":"John","last":"Doe","suffix":"#34"},{"first":"John","last":"Doe","suffix":"#35"},{"first":"John","last":"Doe","suffix":"#36"},{"first":"John","last":"Doe","suffix":"#37"},{"first":"John","last":"Doe","suffix":"#38"},{"first":"John","last":"Doe","suffix":"#39"},{"first":"John","last":"Doe","suffix":"#40"},{"first":"John","last":"Doe","suffix":"#41"},{"first":"John","last":"Doe","suffix":"#42"},{"first":"John","last":"Doe","suffix":"#43"},{"first":"John","last":"Doe","suffix":"#44"},{"first":"John","last":"Doe","suffix":"#45"},{"first":"John","last":"Doe","suffix":"#46"},{"first":"John","last":"Doe","suffix":"#47"},{"first":"John","last":"Doe","suffix":"#48"},{"first":"John","last":"Doe","suffix":"#49"},{"first":"John","last":"Doe","suffix":"#50"},{"first":"John","last":"Doe","suffix":"#51"},{"first":"John","last":"Doe","suffix":"#52"},{"first":"John","last":"Doe","suffix":"#53"},{"first":"John","last":"Doe","suffix":"#54"},{"first":"John","last":"Doe","suffix":"#55"},{"first":"John","last":"Doe","suffix":"#56"},{"first":"John","last":"Doe","suffix":"#57"},{"first":"John","last":"Doe","suffix":"#58"},{"first":"John","last":"Doe","suffix":"#59"},{"first":"John","last":"Doe","suffix":"#60"},{"first":"John","last":"Doe","suffix":"#61"},{"first":"John","last":"Doe","suffix":"#62"},{"first":"John","last":"Doe","suffix":"#63"},{"first":"John","last":"Doe","suffix":"#64"},{"first":"John","last":"Doe","suffix":"#65"},{"first":"John","last":"Doe","suffix":"#66"},{"first":"John","last":"Doe","suffix":"#67"},{"first":"John","last":"Doe","suffix":"#68"},{"first":"John","last":"Doe","suffix":"#69"},{"first":"John","last":"Doe","suffix":"#70"},{"first":"John","last":"Doe","suffix":"#71"},{"first":"John","last":"Doe","suffix":"#72"},{"first":"John","last":"Doe","suffix":"#73"},{"first":"John","last":"Doe","suffix":"#74"},{"first":"John","last":"Doe","suffix":"#75"},{"first":"John","last":"Doe","suffix":"#76"},{"first":"John","last":"Doe","suffix":"#77"},{"first":"John","last":"Doe","suffix":"#78"},{"first":"John","last":"Doe","suffix":"#79"},{"first":"John","last":"Doe","suffix":"#80"},{"first":"John","last":"Doe","suffix":"#81"},{"first":"John","last":"Doe","suffix":"#82"},{"first":"John","last":"Doe","suffix":"#83"},{"first":"John","last":"Doe","suffix":"#84"},{"first":"John","last":"Doe","suffix":"#85"},{"first":"John","last":"Doe","suffix":"#86"},{"first":"John","last":"Doe","suffix":"#87"},{"first":"John","last":"Doe","suffix":"#88"},{"first":"John","last":"Doe","suffix":"#89"},{"first":"John","last":"Doe","suffix":"#90"},{"first":"John","last":"Doe","suffix":"#91"},{"first":"John","last":"Doe","suffix":"#92"},{"first":"John","last":"Doe","suffix":"#93"},{"first":"John","last":"Doe","suffix":"#94"},{"first":"John","last":"Doe","suffix":"#95"},{"first":"John","last":"Doe","suffix":"#96"},{"first":"John","last":"Doe","suffix":"#97"},{"first":"John","last":"Doe","suffix":"#98"},{"first":"John","last":"Doe","suffix":"#99"},{"first":"John","last":"Doe","suffix":"#100"},{"first":"John","last":"Doe","suffix":"#101"},{"first":"John","last":"Doe","suffix":"#102"},{"first":"John","last":"Doe","suffix":"#103"},{"first":"John","last":"Doe","suffix":"#104"},{"first":"John","last":"Doe","suffix":"#105"},{"first":"John","last":"Doe","suffix":"#106"},{"first":"John","last":"Doe","suffix":"#107"},{"first":"John","last":"Doe","suffix":"#108"},{"first":"John","last":"Doe","suffix":"#109"},{"first":"John","last":"Doe","suffix":"#110"},{"first":"John","last":"Doe","suffix":"#111"},{"first":"John","last":"Doe","suffix":"#112"},{"first":"John","last":"Doe","suffix":"#113"},{"first":"John","last":"Doe","suffix":"#114"},{"first":"John","last":"Doe","suffix":"#115"},{"first":"John","last":"Doe","suffix":"#116"},{"first":"John","last":"Doe","suffix":"#117"},{"first":"John","last":"Doe","suffix":"#118"},{"first":"John","last":"Doe","suffix":"#119"},{"first":"John","last":"Doe","suffix":"#120"},{"first":"John","last":"Doe","suffix":"#121"},{"first":"John","last":"Doe","suffix":"#122"},{"first":"John","last":"Doe","suffix":"#123"},{"first":"John","last":"Doe","suffix":"#124"},{"first":"John","last":"Doe","suffix":"#125"},{"first":"John","last":"Doe","suffix":"#126"},{"first":"John","last":"Doe","suffix":"#127"},{"first":"John","last":"Doe","suffix":"#128"},{"first":"John","last":"Doe","suffix":"#129"},{"first":"John","last":"Doe","suffix":"#130"},{"first":"John","last":"Doe","suffix":"#131"},{"first":"John","last":"Doe","suffix":"#132"},{"first":"John","last":"Doe","suffix":"#133"},{"first":"John","last":"Doe","suffix":"#134"},{"first":"John","last":"Doe","suffix":"#135"},{"first":"John","last":"Doe","suffix":"#136"},{"first":"John","last":"Doe","suffix":"#137"},{"first":"John","last":"Doe","suffix":"#138"},{"first":"John","last":"Doe","suffix":"#139"},{"first":"John","last":"Doe","suffix":"#140"},{"first":"John","last":"Doe","suffix":"#141"},{"first":"John","last":"Doe","suffix":"#142"},{"first":"John","last":"Doe","suffix":"#143"},{"first":"John","last":"Doe","suffix":"#144"},{"first":"John","last":"Doe","suffix":"#145"},{"first":"John","last":"Doe","suffix":"#146"},{"first":"John","last":"Doe","suffix":"#147"},{"first":"John","last":"Doe","suffix":"#148"},{"first":"John","last":"Doe","suffix":"#149"},{"first":"John","last":"Doe","suffix":"#150"},{"first":"John","last":"Doe","suffix":"#151"},{"first":"John","last":"Doe","suffix":"#152"},{"first":"John","last":"Doe","suffix":"#153"},{"first":"John","last":"Doe","suffix":"#154"},{"first":"John","last":"Doe","suffix":"#155"},{"first":"John","last":"Doe","suffix":"#156"},{"first":"John","last":"Doe","suffix":"#157"},{"first":"John","last":"Doe","suffix":"#158"},{"first":"John","last":"Doe","suffix":"#159"},{"first":"John","last":"Doe","suffix":"#160"},{"first":"John","last":"Doe","suffix":"#161"},{"first":"John","last":"Doe","suffix":"#162"},{"first":"John","last":"Doe","suffix":"#163"},{"first":"John","last":"Doe","suffix":"#164"},{"first":"John","last":"Doe","suffix":"#165"},{"first":"John","last":"Doe","suffix":"#166"},{"first":"John","last":"Doe","suffix":"#167"},{"first":"John","last":"Doe","suffix":"#168"},{"first":"John","last":"Doe","suffix":"#169"},{"first":"John","last":"Doe","suffix":"#170"},{"first":"John","last":"Doe","suffix":"#171"},{"first":"John","last":"Doe","suffix":"#172"},{"first":"John","last":"Doe","suffix":"#173"},{"first":"John","last":"Doe","suffix":"#174"},{"first":"John","last":"Doe","suffix":"#175"},{"first":"John","last":"Doe","suffix":"#176"},{"first":"John","last":"Doe","suffix":"#177"},{"first":"John","last":"Doe","suffix":"#178"},{"first":"John","last":"Doe","suffix":"#179"},{"first":"John","last":"Doe","suffix":"#180"},{"first":"John","last":"Doe","suffix":"#181"},{"first":"John","last":"Doe","suffix":"#182"},{"first":"John","last":"Doe","suffix":"#183"},{"first":"John","last":"Doe","suffix":"#184"},{"first":"John","last":"Doe","suffix":"#185"},{"first":"John","last":"Doe","suffix":"#186"},{"first":"John","last":"Doe","suffix":"#187"},{"first":"John","last":"Doe","suffix":"#188"},{"first":"John","last":"Doe","suffix":"#189"},{"first":"John","last":"Doe","suffix":"#190"},{"first":"John","last":"Doe","suffix":"#191"},{"first":"John","last":"Doe","suffix":"#192"},{"first":"John","last":"Doe","suffix":"#193"},{"first":"John","last":"Doe","suffix":"#194"},{"first":"John","last":"Doe","suffix":"#195"},{"first":"John","last":"Doe","suffix":"#196"},{"first":"John","last":"Doe","suffix":"#197"},{"first":"John","last":"Doe","suffix":"#198"},{"first":"John","last":"Doe","suffix":"#199"}],
//         currentPage: 1,
//          perPage: 5,
//         //  pages: [],
//          submitUserName:"helloworld",
//          chatTabs: [
//           {
//             title: 'Boopathi',
//             id: '845f506f-d8fe-480e-810b-853ea49aecd3',
//             state : "connected"
//           }, {
//             title: 'Kumar',
//             id: '2',
//             state : "connected"
//           },
//         ],items: [
//           { id: 1, first_name: 'Fred', last_name: 'Flintstone',link:"https://www.google.com" },
//           { id: 2, first_name: 'Wilma', last_name: 'Flintstone',link:"https://www.google.com" },
//           { id: 3, first_name: 'Barney', last_name: 'Rubble' ,link:"https://www.google.com"},
//           { id: 4, first_name: 'Betty', last_name: 'Rubble' ,link:"https://www.google.com"},
//           { id: 5, first_name: 'Pebbles', last_name: 'Flintstone',link:"https://www.google.com" },
//           { id: 6, first_name: 'Bamm Bamm', last_name: 'Rubble',link:"https://www.google.com" },
//           { id: 7, first_name: 'The Great', last_name: 'Gazzoo',link:"https://www.google.com" },
//           { id: 8, first_name: 'Rockhead', last_name: 'Slate',link:"https://www.google.com" },
//           { id: 9, first_name: 'Pearl', last_name: 'Slaghoople' ,link:"https://www.google.com"}
//         ],
        
     
        
//           },
//         methods : {
//           searchMethod (){
//             console.log(this.searchInfo)

//           },
//           getPosts () {
//             let data = [];
//             for(let i = 0; i < 50; i++){
//               this.posts.push({first: 'John',
//                      last:'Doe', 
//                      suffix:'#' + i});
//             }  
//             console.log(JSON.stringify(this.posts))
//             return this.posts
         
//         },setPages () {
//           let numberOfPages = Math.ceil(this.posts.length / this.perPage);
//           for (let index = 1; index <= numberOfPages; index++) {
//           this.pages.push(index);
//           }
//           },
//           paginate (posts) {
//           let page = this.page;
//           let perPage = this.perPage;
//           let from = (page * perPage) - perPage;
//           let to = (page * perPage);
//           return  posts.slice(from, to);
//           },
//           openDocument(link){
//             console.log(link)
//              window.open(link)
//           }
//       },
//         watch : {
//           selectedTicket :  {
//             handler: function(val) {
//               this.watchSelectedTicket(val)
//             }
//           }
//         },
//         computed: {
//           displayedPosts () {
//             return this.paginate(this.posts);
//             }
//         },
//         components: {
//           VPaginator: VuePaginator
//         }
//       })
//     }
//   }
// };

// function onAppActivate(){
// console.log('APP ACTIVATED')
// }

// function handleErr(err) {
//   console.error(`Error occured. Details:`, err);
// }

var vm
var client


// Vue.filter('htmlEscape', function(value) {
//   return value.replace(/\&amp\;/g, '&');
// });
// Vue.filter('dateTime', function(val) {
//   return new Date(val).toGMTString().slice(0, -13);


// });




 document.onreadystatechange = function() {
    if (document.readyState === 'interactive') renderApp();
  
    function renderApp() {
      var onInit = app.initialized();
  
      onInit.then(getClient);
  
      function getClient(_client) {
      client = _client;
        client.events.on('app.activated', onAppActivate);
  
  
        
        // Vue.filter('formatDateDiffForHumans', function(value) {
        //   if (!value) return null;
        //   return dayjs(value).format('h:mm A');
        // });
        
  
   vm = new Vue({
  el: '#wikiApp',
  data: {
    wikiObj: [],
    isResult: false,
    searchQuery: '',
    
  },
  computed: {

  },
  // ready: function() {
  // },
  methods: {
    removeSearchQuery: function() {
      this.searchQuery = '';
      this.isResult = false;
    },
    // submitSearch: function() {
    //   var reqURL = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrnamespace=0&exsentences=1&exintro&explaintext&exlimit=max&prop=extracts&gsrlimit=10&gsrsearch="+this.searchQuery+"&format=json";
     
    //   this.$http.jsonp(reqURL).then(function(response) {
    //     this.wikiObj = response.data.query.pages;
    //     this.isResult = true;
    //   }, function(response) { /* fail response msg */
    //     console.log(response);
    //   });
    // }
   async submitSearch(){
     let result = []
     client.request.get("https://jlontm3tlj.execute-api.us-east-1.amazonaws.com/default/nyraScriptLambda?search="+this.searchQuery).then(data => {
                result = JSON.parse(data.response)
                this.wikiObj = result
                console.log(result)
     })
    
      console.log(this.searchQuery)
      this.wikiObj = []
      this.isResult = true;
      
      // let res = await axios.get("https://jlontm3tlj.execute-api.us-east-1.amazonaws.com/default/nyraScriptLambda?search=pass")
      // console.log(res)
      
    },
    openLink(id){
      console.log('THIS IS IDDDDDD',id)
      window.open('https://nyra-script-bucket.s3.amazonaws.com/Files/NBets22_Application_Freshworks.pdf?AWSAccessKeyId=ASIA5CLG2CPZCQYZJJUK&Signature=nF7eSZU9YssnGvrpJ6oigm9Vgnk%3D&x-amz-security-token=IQoJb3JpZ2luX2VjEGwaCXVzLWVhc3QtMSJHMEUCIGRuNUCRfCgzL0TTVdcjilyADMa7LKAa8ZLUgzXCl6nEAiEAwfPldlFAl40bxLmQ2Lg%2BWhxz%2FKakj%2FM0jMAL9AtA7mYqngII1f%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw4OTg0MDA2NTQzMjIiDEdnXR5nONkDA3RFPyryAfYGuDWHoeaKQ8%2FkwhiHAAfzOP4%2FEHfUwi%2F3qRpnwjUFEIyuvtA3p047LkBSo5pzRo6XtvG6Jdeiz0Lryq3YcxdajEJmmEFjoBLUZyYxga0GIj8UxdNKN7r9tzw75DE86aFVEfXz2%2Ba6cjze6i0TQU6uYtRyfiQi%2BRXHxl7z2U0uzounH9E5%2Fw3xNWR3Sd1PIvAdEzdKtuPGYCm%2BRJIskCtKOgk6y%2BtJ8xF7shc8v4%2FLWpcwUPI51Nuj3vP0uBJ8x9XOiDcnlfxXKYBkimF0QMaPgv9zVO8TgCNhpWh3TlYRCNQAxrY3r2w%2Bbu9R6ZW7iKUXMKKpopEGOpoBF%2FiApO5MAeFqWFXffr3c3sSwm%2F58%2FWR2zn1jrQvUanwpdq2KWMtx%2BZIpC2vEloIshdxyLeaWQ13DFNrIk%2BoP%2Fvkuo2jbDgksUrwdoVaAYAEoYBSblM67jFIEmwN9j4mgGa5MZt2FctS%2BFENEpgGQUt%2FE2%2F3aFyXe5im4Xr6iz1oFfk57NV4y6xYZI%2FIYrz3c8%2FoI0t3CWhBgaQ%3D%3D&Expires=1646830260',)
    }
  }
})

function onAppActivate(){
  console.log("App Activated")
}




      }
    }}